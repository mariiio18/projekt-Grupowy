
from flask import Flask, render_template, request, jsonify
from openai import OpenAI

client = OpenAI(api_key="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")

# Konfiguracja OpenAI API
  # Wprowadź tutaj swój klucz API

app = Flask(__name__, static_folder="static", template_folder="templates")

def chatbot_response(message):
    """
    Generowanie odpowiedzi z OpenAI ChatGPT.
    """
    try:
        response = client.chat.completions.create(model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "Jesteś pomocnym asystentem."},
            {"role": "user", "content": message}
        ])
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Błąd podczas komunikacji z modelem: {e}"

@app.route("/")
def index():
    """
    Strona główna - serwuje plik index.html.
    """
    return render_template("index.html")

@app.route("/get_response", methods=["POST"])
def get_response():
    """
    API do obsługi wiadomości użytkownika.
    """
    user_message = request.json.get("message")
    response = chatbot_response(user_message)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
