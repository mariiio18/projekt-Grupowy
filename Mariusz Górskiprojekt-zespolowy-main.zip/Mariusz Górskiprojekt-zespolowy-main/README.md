# projekt-zespolowy
wersja podstawowa projektu jak macie jakie pomysly na ulepszenia czy zmiany to smialo
